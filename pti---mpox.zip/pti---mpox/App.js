import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, SafeAreaView, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

function WelcomeScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Mpox Tracker</Text>
      <Text style={styles.subtitle}>Ajude a registrar e controlar casos de Mpox</Text>
      <Button title="Começar Cadastro" onPress={() => navigation.navigate('Cadastro')} />
    </SafeAreaView>
  );
}

function CadastroScreen({ navigation }) {
  const [nome, setNome] = useState('');
  const [idade, setIdade] = useState('');
  const [sexo, setSexo] = useState('');
  const [localizacao, setLocalizacao] = useState('');

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Cadastro do Usuário</Text>

      <TextInput
        style={styles.input}
        placeholder="Nome completo"
        value={nome}
        onChangeText={setNome}
      />
      <TextInput
        style={styles.input}
        placeholder="Idade"
        keyboardType="numeric"
        value={idade}
        onChangeText={setIdade}
      />
      <TextInput
        style={styles.input}
        placeholder="Sexo (M/F/Outro)"
        value={sexo}
        onChangeText={setSexo}
      />
      <TextInput
        style={styles.input}
        placeholder="Cidade / Estado"
        value={localizacao}
        onChangeText={setLocalizacao}
      />

      <Button
        title="Avançar para Registro de Sintomas"
        onPress={() =>
          navigation.navigate('Sintomas', {
            nome,
            idade,
            sexo,
            localizacao,
          })
        }
      />
    </ScrollView>
  );
}

function SintomasScreen({ route, navigation }) {
  const { nome, idade, sexo, localizacao } = route.params;
  const [sintomas, setSintomas] = useState('');

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Registro de Sintomas</Text>

      <TextInput
        style={styles.input}
        placeholder="Descreva seus sintomas"
        value={sintomas}
        onChangeText={setSintomas}
        multiline
        numberOfLines={4}
      />

      <Button
        title="Avançar para Contato"
        onPress={() =>
          navigation.navigate('Contato', {
            nome,
            idade,
            sexo,
            localizacao,
            sintomas,
          })
        }
      />
    </ScrollView>
  );
}

function ContatoScreen({ route, navigation }) {
  const { nome, idade, sexo, localizacao, sintomas } = route.params;
  const [contato, setContato] = useState('');

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Você conhece alguém com sintomas?</Text>

      <TextInput
        style={styles.input}
        placeholder="Digite o nome ou relação da pessoa"
        value={contato}
        onChangeText={setContato}
      />

      <Button
        title="Finalizar e Ver Dados"
        onPress={() =>
          navigation.navigate('Resumo', {
            nome,
            idade,
            sexo,
            localizacao,
            sintomas,
            contato,
          })
        }
      />
    </ScrollView>
  );
}

function ResumoScreen({ route }) {
  const { nome, idade, sexo, localizacao, sintomas, contato } = route.params;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Resumo dos Dados</Text>
      <Text>Nome: {nome}</Text>
      <Text>Idade: {idade}</Text>
      <Text>Sexo: {sexo}</Text>
      <Text>Localização: {localizacao}</Text>
      <Text>Sintomas: {sintomas}</Text>
      <Text>Contato com Sintomático: {contato}</Text>
    </ScrollView>
  );
}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Bem-vindo">
        <Stack.Screen name="Bem-vindo" component={WelcomeScreen} />
        <Stack.Screen name="Cadastro" component={CadastroScreen} />
        <Stack.Screen name="Sintomas" component={SintomasScreen} />
        <Stack.Screen name="Contato" component={ContatoScreen} />
        <Stack.Screen name="Resumo" component={ResumoScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
    paddingTop: 40,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 30,
  },
  input: {
    borderWidth: 1,
    borderColor: '#aaa',
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
  },
});
